import random
import tkinter as tk
import pyperclip

# Function for generating a random login
def generate_random_login(length):
    rand_string = ''.join(random.choice(login_chars) for _ in range(length))
    return rand_string

# Function for generating a random password
def generate_random_password(length):
    rand_string = ''.join(random.choice(password_chars) for _ in range(length))
    return rand_string

# Function to update the output of generated data and copy to clipboard
def update_output():
    login_length = int(login_length_entry.get())
    password_length = int(password_length_entry.get())

    generated_login = generate_random_login(login_length)
    generated_password = generate_random_password(password_length)

    result_text = f"login: {generated_login}; password: {generated_password}"
    output_label.config(text=result_text)

    # Copy the result to the clipboard
    pyperclip.copy(result_text)

    # Adding an inscription
    copied_label.config(text="Text copied")

# Creating the main window
root = tk.Tk()
root.title("Login and password generator")

# Character strings for login and password
login_chars = "abcdefghijklmnpqrtuuvxyz123456789"
password_chars = "ABCDEFGHIJKLMNOPQRSTUVXYZ123456789"

# Creating and placing controls
login_length_label = tk.Label(root, text="Login length:")
login_length_label.pack()

login_length_entry = tk.Entry(root)
login_length_entry.pack()

password_length_label = tk.Label(root, text="Password length:")
password_length_label.pack()

password_length_entry = tk.Entry(root)
password_length_entry.pack()

generate_button = tk.Button(root, text="Generate and copy", command=update_output)
generate_button.pack()

output_label = tk.Label(root, text="")
output_label.pack()

copied_label = tk.Label(root, text="")
copied_label.pack()

# Launching the main GUI loop
root.mainloop()
